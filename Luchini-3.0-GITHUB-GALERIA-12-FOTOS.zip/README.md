# LUCHINI VITRINE 3.0 - GALERIA 12 FOTOS + GITHUB

## 🎯 O QUE ESTE PACOTE RESOLVE
- Cliente não atualizava porque usava localStorage só no seu navegador
- Agora usa GitHub + veiculos.json = atualiza para TODOS automaticamente
- Galeria de 8 a 12 fotos por carro

## 📦 O QUE TEM NA PASTA
- index.html = vitrine cliente (link público)
- admin.html = vitrine gerente (senha 2501)
- veiculos.json = banco de dados dos carros (vai pro GitHub)
- netlify.toml = config do Netlify
- manifest.json + icons = PWA

## 🚀 PASSO A PASSO PARA FICAR FUNCIONAL (5 MINUTOS)

### PASSO 1 - CRIAR CONTA GITHUB (se não tiver)
1. Vai em https://github.com e cria conta gratuita
2. Confirma email

### PASSO 2 - CRIAR REPOSITÓRIO
1. Logado no GitHub, clica no + no topo > New repository
2. Nome: `luchini-vitrine`
3. Marca Public
4. Marca Add a README file
5. Clica Create repository

### PASSO 3 - SUBIR ESTE PACOTE PRO GITHUB
1. Dentro do repositório criado, clica em Add file > Upload files
2. Arrasta TODOS os arquivos desta pasta (index.html, admin.html, veiculos.json, netlify.toml, etc)
3. Clica Commit changes

### PASSO 4 - CONECTAR GITHUB AO NETLIFY (ATUALIZAÇÃO AUTOMÁTICA)
1. Vai em https://app.netlify.com/
2. Clica Add new site > Import an existing project
3. Escolhe GitHub e autoriza
4. Escolhe o repositório `luchini-vitrine`
5. Deixa tudo padrão:
   - Build command: (deixa vazio)
   - Publish directory: .
6. Clica Deploy site
7. Pronto! Vai gerar um link tipo https://seu-site-novo.netlify.app
   - Esse link vai atualizar SOZINHO toda vez que você subir algo no GitHub

### PASSO 5 - COMO CADASTRAR CARRO COM 12 FOTOS
1. Acesse: https://seu-site-novo.netlify.app/admin.html
2. Senha: 2501
3. Clica + Novo Veículo
4. Preencha modelo, ano, preço (obrigatórios)
5. Clique em "Escolher até 12 fotos" > selecione várias fotos do carro no celular (segure para selecionar várias)
6. Vai aparecer grade com previews, primeira é CAPA
7. Pode clicar X para remover foto indesejada
8. Clique Salvar na vitrine
9. Clique no botão "Exportar veiculos.json para GitHub" (no topo do modo gerente)
10. Vai baixar arquivo veiculos.json atualizado
11. Volta no GitHub > seu repositório > clica no arquivo veiculos.json > clica no lápis (edit) > apaga tudo e cola conteúdo do arquivo que baixou > Commit changes
12. Em 30 segundos, site do cliente atualiza para TODO MUNDO com fotos novas!

### PASSO 6 - LINKS FINAIS
- Cliente (divulgue): https://seu-site-novo.netlify.app/
- Gerente (só equipe): https://seu-site-novo.netlify.app/admin.html - senha 2501

### DICA FOTOS
- Tire fotos na horizontal
- Até 12 fotos: frente, traseira, lateral, interior, painel, motor, etc
- Sistema comprime automaticamente
- Primeira foto = capa

### SUPORTE
- WhatsApp vitrine: (11) 4583-4515
- Senha gerente: 2501
- Fotos: máximo 12 por carro

## ATUALIZAÇÃO FUTURA
Sempre que quiser adicionar/remover carro:
1. Entra no admin.html > faz alteração > Exportar veiculos.json
2. Sobe veiculos.json no GitHub (substitui)
3. Netlify atualiza sozinho!

FIM
